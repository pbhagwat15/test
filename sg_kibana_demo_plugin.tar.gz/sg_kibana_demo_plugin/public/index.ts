import './index.scss';

import { SgKibanaDemoPluginPlugin } from './plugin';

// This exports static code and TypeScript types,
// as well as, Kibana Platform `plugin()` initializer.
export function plugin() {
  return new SgKibanaDemoPluginPlugin();
}
export type { SgKibanaDemoPluginPluginSetup, SgKibanaDemoPluginPluginStart } from './types';
