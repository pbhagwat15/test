export const PLUGIN_ID = 'sgKibanaDemoPlugin';
export const PLUGIN_NAME = 'sgKibanaDemoPlugin';
